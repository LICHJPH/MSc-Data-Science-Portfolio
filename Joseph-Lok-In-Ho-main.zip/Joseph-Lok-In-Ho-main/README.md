# Joseph-Lok-In-Ho
This page is a showcase of my python pragramming skills

The task is to identify if any personality traits(confidence, composure, impulsitivity etc) are associated to the volume of their investiment amount and it's asset's type.

The folder contains the results report and the coding.

Before running the script, update the file path on line 31:

```python
# original
personality = pd.read_csv('/Users/cola/Desktop/pythonProject2/personality.csv')

# update to your own path
personality = pd.read_csv('<your_local_path>/personality.csv')
```

Combined. csv file is the file that has both data from personality.csv and the data retrieve through REST API
